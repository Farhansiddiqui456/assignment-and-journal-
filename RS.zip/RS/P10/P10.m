% Practical 10 - Write a program to perform smoothing on a given image
clc;
clear all;
close all;

img = imread('D:\RS\1671458913727.jpg');
grayImage = rgb2gray(img)
subplot(2,3,1);
imshow(grayImage);

title('Original Image');
grayImage1 = imnoise(grayImage, 'salt & pepper')
subplot(2,3,2);
imshow(grayImage1);
title('Noise Image');

blurredImage = imfilter(grayImage1, ones(3)/9, 'symmetric');
subplot(2,3,3);
imshow(blurredImage);
title('Blurred Image (3x3)');

blurredImage = imfilter(grayImage1, ones(5)/25, 'symmetric');
subplot(2,3,4);
imshow(blurredImage);
title('Blurred Image (5x5)');

blurredImage = imfilter(grayImage1, ones(7)/49, 'symmetric');
subplot(2,3,5);
imshow(blurredImage);
title('Blurred Image (7x7)');

blurredImage = imfilter(grayImage1, ones(9)/81, 'symmetric');
subplot(2,3,6);
imshow(blurredImage);
title('Blurred Image (9x9)');