close all;
clear all;
clc;
img2=imread('D:\RS\P1\1671458913727.jpg')
img1 = rgb2gray(img2);
subplot(1,2,1);
imshow(img1);
imshow(img1);
title('Original Image');
B=double(img1)*(10);
subplot(1,2,2)
imshow(uint8(B))
title('Contrast Adjusted')