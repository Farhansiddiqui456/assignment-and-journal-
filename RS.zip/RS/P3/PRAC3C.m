% Prac 3C:- gray scale slicing with background
clc;
clear all;
close all;
img = imread('D:\RS\P1\1671458913727.jpg');
subplot(1,2,1);
imshow(img);
title('Original image');
j= double(img);
[ row col ]=size(j);
T1=input('Enter the value for Lowest HRESHOLD');
T2=input('Enter the value for Highest HRESHOLD');
for x=1:1:row
      for y=1:1:col
            if(j(x,y)>T1 && (j(x,y)<T2))
                 j(x,y)=255;
            else
                   j(x,y)=img(x,y);
            end
      end
end
subplot(1,2,2);
imshow(uint8(j));
title('Gray Level Slicing with Background') 