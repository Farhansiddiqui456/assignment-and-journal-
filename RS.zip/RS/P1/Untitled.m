clc;
clear all;
close all;

% - Reading the image
a= imread('D:\RS\P1\1671458913727.jpg')

% - Converting color image to gray scale image
b=rgb2gray(a)


% Creating the output window
figure();


% Dividing the output window into multiple section
subplot(1,2,1);

%Display the image
imshow(a)

%Giving the title to the image
title('Color Image');


subplot(1,2,2);
imshow(b);
title('Grey Scale Image');