%Practical 4A-Power Law Transformation
clc;
clear all;
close all;
img1 = imread('D:\RS\P1\1671458913727.jpg');
img = rgb2gray(img1)
subplot(1,2,1)
imshow(img);
title('Original Image');
[ row col ]=size(img);
c=1;
img=double(img);
gamma=0.5;
for x=1:row
     for y=1:col
          j(x,y)=c*(img(x,y)^gamma);
     end;
end;
subplot(1,2,2);
imshow(j,[])
title('Power Law Transform');

