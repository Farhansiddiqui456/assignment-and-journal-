%Practical 4B- Log Transformation
clc;
clear all;
close all;
img1 = imread('D:\RS\P1\1671458913727.jpg');
img = rgb2gray(img1);
subplot(1,2,1)
imshow(img);
title('Original Image');
L=255;
c=L/log10(1+L);
d= c*(log10 (1+double(img)));
subplot(1,2,2)
imshow(uint8(d));
title('Log Transformation');