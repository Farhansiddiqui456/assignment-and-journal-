% Practical 11 - Perform sharpening on a given image

clc;
clear all;
close all;

img = imread('D:\RS\1671458913727.jpg');
a = rgb2gray(img);
lap = [1 1 1; 1 -8 1; 1 1 1];
resp = uint8(filter2(lap, a, 'same'));
sharpened = imsubtract(a, resp);

subplot(1,3,1);
imshow(a);
title('Original Image');

subplot(1,3,2);
imshow(resp);
title('Laplacian Filtered Image');

subplot(1,3,3);
imshow(sharpened);
title('Sharpened Image');