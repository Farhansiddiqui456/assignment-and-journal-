%Practical 9b - Pseudocoloring
clc;
clear all;
close all;

img=imread('D:\RS\1671458913727.jpg');
subplot(1,2,1);
imshow(img);
title('original image')

redp=img(:,:,1);
greenp=img(:,:,2);
bluep=img(:,:,3);

OP(:,:,1)=greenp;
OP(:,:,2)=bluep;
OP(:,:,3)=redp;
subplot(1,2,2);
imshow(OP);
title('Pseudocolouring');