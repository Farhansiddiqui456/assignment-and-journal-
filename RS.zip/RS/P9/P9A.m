% Practical 9a - RGB planes
clc;
clear all;
close all;

img = imread('D:\RS\1671458913727.jpg');
subplot(1,4,1);
imshow(img);
title('Original Image')

redp = img(:,:,1);
greenp = img(:,:,2);
bluep = img(:,:,3);

subplot(1,4,2);
imshow(redp);
title('Red plane')

subplot(1,4,3);
imshow(bluep);
title('Blue plane')

subplot(1,4,4);
imshow(greenp);
title('Green plane')