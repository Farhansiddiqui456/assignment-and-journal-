% Practical 8 - Write a program to perform Opening and Closing

clc;
clear all;
close all;

w = [0 0 0 0 1 1 1 1 1 1 1 1 0 0;
     0 0 0 0 1 1 1 1 1 1 1 1 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0;
     0 0 0 0 1 1 1 1 1 1 0 0 0 0;
     0 0 0 0 1 1 1 1 1 1 0 0 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0;
     0 0 0 0 1 1 0 0 0 0 0 0 0 0];
 
 disp(w);
 se1 = strel('square',3);
 disp(se1);
 O1 = imerode(w, se1);
 O2 = imdilate(O1, se1);
 
 C1 = imdilate(w,se1);
 C2 = imerode(C1,se1);
 
 subplot(2,3,1);
 imshow(w);
 title('Original Image')
 
 subplot(2,3,2);
 imshow(O1);
 title('Opening - Step 1')
 
 subplot(2,3,3);
 imshow(O2);
 title('Opening - Erosion followed by Dilation')
 
 subplot(2,3,4);
 imshow(w);
 title('Original Image')
 
 subplot(2,3,5);
 imshow(C1);
 title('Closing - Step 1')
 
 subplot(2,3,6);
 imshow(C2);
 title('Closing - Dilation followed by Erosion')
 