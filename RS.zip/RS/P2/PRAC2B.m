close all;
clear all;
clc;

img1=imread('D:\RS\P1\1671458913727.jpg')
img = rgb2gray(img1)
subplot(1,2,1)
imshow(img)
title('Original image')
[ row col ]=size(img)
for x=1:row
      for y=1:col
            img_neg(x,y)=255-img(x,y);
      end
end
img_ne=uint8(img_neg);
subplot(1,2,2);
imshow(img_ne);
title('Negative Image')