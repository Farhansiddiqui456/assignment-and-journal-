clc;
clear all;
close all;

img=imread('D:\RS\P1\1671458913727.jpg');
img1=rgb2gray(img)
subplot(1,3,1);
imshow(img1);
title('Original Image');


B=double(img1)-50;
subplot(1,3,2)
imshow(uint8(B))
title('Brightness Decreased') 

B=double(img1)+150;
subplot(1,3,3)
imshow(uint8(B))
title('Brightness Increased') 